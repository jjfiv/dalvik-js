
public class Const_high16 {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String high = "0x12340000";
        System.out.println(high);

    }
}