
public class Aget_wide {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        long[] arr = new long[2];
        arr[1] = 1000000000000000000l;
	   // System.out.println("Result is 1000000000000000000l");
	    System.out.println(arr[1]);
        
	}

}
