
public class Const_wide {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        double a = 1234567890123232323232232323232323232323232323456788d;
        double b = 1d;
        double c = 0d;
        c = a+b;
		System.out.println(c);

	}
}