
public class Or_long_2addr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long a = 123456789121l;
		long b = 2l;
		long c = 0;
		// Or operation =a | b 
		c = a | b;
		c +=1;
		//System.out.println("a | b = 123456789124");
		System.out.println(c);

	}

}
