
public class And_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

			long a = 987654321;
			long b = 123456789;
			long c = 0;
			// AND operation =a & b 
			c = a & b;
			//System.out.println("a & b = 39471121");
			System.out.println(c);

	}

}
