
public class Div_double_2addr {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        double a = 2.7d;
        double b = 3.14d;
        double c = 0d;
        c = a/b;
        c+=1;
        //System.out.println("Result is 1.8598726114649682d");
		System.out.println(c);

	}
}
