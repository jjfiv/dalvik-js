
public class Double_to_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		double a = 2.9999999d;
		long b = (long) a;

        //System.out.println("Result should be 2l");		
        System.out.println (b);
        

        

	}

}
