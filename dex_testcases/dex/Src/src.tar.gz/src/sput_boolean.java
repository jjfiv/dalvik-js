public class sput_boolean {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Setter_sbool t = new Setter_sbool();

		//System.out.println("Result should be true");
		System.out.println(t.s_set(true));

	}

}

class Setter_sbool {

	public static boolean s_set(boolean s) {
		return s;
	}
}
