
public class Mul_double {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

        double x, y, z;
        x =2.7;
        y = 3.14;
        z = x * y;
        //System.out.println("Reesult should be 8.478000000000002");		
        System.out.println (z);
	}

}
