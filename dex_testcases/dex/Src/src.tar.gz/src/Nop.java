public class Nop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NClass i = new NClass();

		//System.out.println("Result is true");
		System.out.println(i.nop());

	}

}

class NClass {
	public boolean nop() {
		return true;
	}
}
