
public class Double_to_float {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		double a = 2.7d;
		float b = (float) a;

        //System.out.println("Result should be 2.7f");		
        System.out.println (b);
        

        

	}

}
