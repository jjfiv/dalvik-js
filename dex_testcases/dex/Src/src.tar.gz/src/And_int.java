
public class And_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 15;
		int b = 8;
		int c = 0;
		// AND operation =a & b = 2
		c = a & b;
		//System.out.println("a & b = 8");
		System.out.println(c);

	}

}
