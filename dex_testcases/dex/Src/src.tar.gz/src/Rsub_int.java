
public class Rsub_int {

	/**
	 * @param args
	 *            reverse subtraction
	 */
	public static void main(String[] args) {
		int x, y, z;
		x = 8;
		y = 4;
		z = y - x;
		//System.out.println("Reesult should be -4");
		System.out.println(z);

	}

}
