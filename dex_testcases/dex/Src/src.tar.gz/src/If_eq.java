public class If_eq {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 20;
		int b = 20;

		if (a == b)
			//System.out.println("Result should be True");
			System.out.println(a == b);

	}

}
