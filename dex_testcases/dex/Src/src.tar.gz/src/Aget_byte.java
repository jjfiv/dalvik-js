
public class Aget_byte {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        byte[] arr = new byte[2];
       arr[1] = 100;
      // System.out.println("Array 100");
       System.out.println(arr[1]);       

	}

}
