public class Long_to_float {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long a = 123456789012345l;
		float b = (float) a;

		//System.out.println("Result should be 1.23456788E14");
		System.out.println(b);

	}

}
