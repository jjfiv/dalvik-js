public class Goto_32 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 20;

		while (a > 0) {
			a--;
		}

		// System.out.println("Result should be 0");
		System.out.println(a);

	}

}
