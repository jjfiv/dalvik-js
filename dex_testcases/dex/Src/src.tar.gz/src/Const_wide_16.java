
public class Const_wide_16 {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        long a = 10000l;
        long b = 10000l;
        long c = 0l;
        c = a+b;
		System.out.println(c);

	}
}