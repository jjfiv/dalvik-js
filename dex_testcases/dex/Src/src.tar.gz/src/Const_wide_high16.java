
public class Const_wide_high16 {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Long high = new Long(0x1234000000000000l);

        System.out.println(high);

    }
}