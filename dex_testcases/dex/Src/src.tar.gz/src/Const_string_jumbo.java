
public class Const_string_jumbo {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "android jumbo";

		System.out.println(s);

	}
}