
public class Array_length {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String[] a = new String[5];
  
		//System.out.println("Result is 5");
		System.out.println(a.length);


	}

}
