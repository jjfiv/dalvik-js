
public class Xor_int_2addr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 15;
		int b = 8;
		int c = 0;
		// XOR operation =a ^ b = 2
		c = a ^ b;
		c+=1;
		//System.out.println("a ^ b = 8");
		System.out.println(c);

	}

}
