public class Sub_float {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		float x, y, z;
		x = 2.7f;
		y = 3.14f;
		z = x - y;
		//System.out.println("Result should be -0.44000006");
		System.out.println(z);

	}

}
