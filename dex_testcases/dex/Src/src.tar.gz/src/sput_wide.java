public class sput_wide {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Setter_swide t = new Setter_swide();

		//System.out.println("Result should be 778899112233");
		System.out.println(t.s_set(778899112233l));

	}

}

class Setter_swide {
	public static long s;

	public static long s_set(long s) {
		return s;
	}
}