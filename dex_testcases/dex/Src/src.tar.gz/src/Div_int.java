
public class Div_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        int x, y, z;
        x = 8;
        y = 4;
        z = x/ y;
        //System.out.println("Div_ int result should be 2");		
        System.out.println (z);

	}

}