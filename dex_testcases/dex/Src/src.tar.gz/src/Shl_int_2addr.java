public class Shl_int_2addr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Shifts the bits of n left p positions.
		// Zero bits are shifted into the low-order positions.

		int c;
		c = 15 << 1;
		c += 1;
		//System.out.println("Result should be 31");
		System.out.println(c);
	}

}
