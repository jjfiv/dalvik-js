
public class Rem_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
        long x, y, z;
        x = 10000000000l;
        y = 4000000000l;
        z = x % y;
        //System.out.println("Result should be 2000000000");		
        System.out.println (z);

	}

}
