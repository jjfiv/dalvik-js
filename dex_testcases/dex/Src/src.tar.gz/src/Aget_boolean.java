
public class Aget_boolean {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        boolean[] arr = new boolean[2];
        arr[1] = true;
        //System.out.println("True");
        System.out.println(arr[1]);

	}

}
