
public class Long_to_double {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double a = 50000000000l;
		double b = (double) a;

		//System.out.println("Result should be 5.0E10");
		System.out.println(b);

	}

}
