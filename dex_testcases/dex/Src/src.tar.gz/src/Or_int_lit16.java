
public class Or_int_lit16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 15;
		int b = 8;
		int c = 0;
		// Or operation =a | b = 2
		c = a | b;
		//System.out.println("a | b = 15");
		System.out.println(c);

	}

}
