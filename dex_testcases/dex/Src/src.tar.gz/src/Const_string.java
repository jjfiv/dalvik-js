
public class Const_string {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "android";

		System.out.println(s);

	}
}