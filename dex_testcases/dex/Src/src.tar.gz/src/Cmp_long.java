
public class Cmp_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long x, y;
		x = 111234567891l;
		y =	111234567890l;
		
		if(x > y) 
			System.out.println (true);
		else System.out.println(false);		

	}

}
