
public class Div_float {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        float a = 2.7f;
        float b = 3.14f;
        float c = 0f;
        c = a/b;
        //System.out.println("Result is 0.8598726f");
		System.out.println(c);
		

	}
}
