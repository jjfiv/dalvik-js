
public class Div_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
        long x, y, z;
        x = 100000000000l;
        y = 40000000000l;
        z = x/y;
        //System.out.println("Div result should be 2l");		
        System.out.println (z);
        

	}

}
