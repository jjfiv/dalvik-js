
public class Aput_byte {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        byte[] arr = new byte[2];
        arr[1] = 100;
		//System.out.println("Result is 100");
		System.out.println(arr[1]);



	}

}
