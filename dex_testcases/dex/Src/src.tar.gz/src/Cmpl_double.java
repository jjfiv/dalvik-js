
public class Cmpl_double {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double x, y;
		x = 3.14d;
		y = 2.7d;

		if (x > y)
			System.out.println(true);
		else
			System.out.println(false);

	}

}
