
public class Aput_boolean {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        boolean[] arr = new boolean[2];
		arr[1] = true;
		//System.out.println("Result is true");
		System.out.println(arr[1]);
		
	}

}
