
public class Check_cast {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "";
		//System.out.println("Result is null");
		System.out.println(s);

	}

}
