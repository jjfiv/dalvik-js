
public class Mul_int {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        int x, y, z;
        x = 8;
        y = 4;
        z = x * y;
        //System.out.println("Result should be 32");		
        System.out.println (z);

	}

}
