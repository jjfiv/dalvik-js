public class Sub_long {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long x, y, z;
		x = 12345678l;
		y = 87654321l;
		z = x - y;
		//System.out.println("Result should be -75308643");
		System.out.println(z);

	}

}
