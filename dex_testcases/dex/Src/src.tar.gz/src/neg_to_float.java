
public class neg_to_float {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 float a = 1f;
		float b = a;

		//System.out.println("Result should be -1.0");
		System.out.println(-b);

	}

}
