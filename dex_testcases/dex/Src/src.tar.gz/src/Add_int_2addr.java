
public class Add_int_2addr {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int x, y, z;
        x = 8;
        y = 4;
        z = x+ y;
        z+=1;
       // System.out.println("Add_ int result should be 13");		
        System.out.println (z);

	}

}
