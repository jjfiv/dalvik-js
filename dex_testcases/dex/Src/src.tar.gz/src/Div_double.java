
public class Div_double {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        double a = 2.7d;
        double b = 3.14d;
        double c = 0d;
        c = a/b;
        //System.out.println("Result is 0.8598726114649682d");
		System.out.println(c);

	}
}
