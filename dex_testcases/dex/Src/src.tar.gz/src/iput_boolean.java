public class iput_boolean {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Setter_ibool t = new Setter_ibool();

		//System.out.println("Result should be true");
		System.out.println(t.i_set(true));

	}

}

class Setter_ibool {

	public boolean i_set(boolean i) {
		return i;
	}
}
